<?php

echo "Received " . $_REQUEST['name'];

?>